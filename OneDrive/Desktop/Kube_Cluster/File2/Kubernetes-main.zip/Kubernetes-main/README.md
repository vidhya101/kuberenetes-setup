# Kubernetes

Some labs/how-to on Kubernetes
[Videos available HERE](https://www.youtube.com/channel/UCkbnSq268JI71B39LiG0Y3g "vNugget YouTube Cahnnel")
