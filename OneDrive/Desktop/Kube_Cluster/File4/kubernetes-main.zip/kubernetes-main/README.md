# kubernetes
Kubernetes code

<a href="https://github.com/ImaginCloud/kubernetes/tree/main/setup-k8s/theHardWay#-setup-multi-master-kubernetes-cluster---the-hard-way-" >Setup Multi-Master Kubernetes Cluster v1.22.0 - THE HARD WAY</a>

<a href="https://github.com/ImaginCloud/kubernetes/tree/main/setup-k8s/vagrant-kubeadm" >Setup Kubernetes Cluster using Kubeadm using automated script v1.22.0 </a>