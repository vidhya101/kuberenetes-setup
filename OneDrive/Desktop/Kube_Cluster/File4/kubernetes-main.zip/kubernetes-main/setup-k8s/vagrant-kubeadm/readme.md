
<h1>Setup Kubernetes Cluster using Kubeadm using automated script v1.22.0</h1>

![Setup Kubernetes Cluster](/setup-k8s/vagrant-kubeadm/Thumbnail.png "Setup Kubernetes Cluster")

<a href="https://www.youtube.com/watch?v=JJbUNRGoxmk&t=75s" >Please refer youtube video for explaination </a>